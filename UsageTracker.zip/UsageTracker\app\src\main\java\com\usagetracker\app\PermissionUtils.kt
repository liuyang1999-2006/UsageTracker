package com.usagetracker.app

import android.app.AppOpsManager
import android.content.Context
import android.os.Build
import android.os.Process

object PermissionUtils {

    /**
     * 「使用情况访问权限」属于 AppOps 特殊权限，不走运行时权限流程，
     * 只能引导用户到系统设置页开启，然后用 AppOpsManager 检查实际状态。
     */
    fun hasUsageAccess(context: Context): Boolean {
        val appOps = context.getSystemService(Context.APP_OPS_SERVICE) as AppOpsManager
        val mode = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.R) {
            appOps.unsafeCheckOpNoThrow(
                AppOpsManager.OPSTR_GET_USAGE_STATS,
                Process.myUid(),
                context.packageName
            )
        } else {
            @Suppress("DEPRECATION")
            appOps.checkOpNoThrow(
                AppOpsManager.OPSTR_GET_USAGE_STATS,
                Process.myUid(),
                context.packageName
            )
        }
        return mode == AppOpsManager.MODE_ALLOWED
    }
}
