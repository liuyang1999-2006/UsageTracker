package com.usagetracker.app

import android.app.usage.UsageEvents
import android.app.usage.UsageStatsManager
import android.content.Context
import android.graphics.drawable.Drawable
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Date
import java.util.HashMap
import java.util.Locale

data class AppUsageInfo(
    val packageName: String,
    val appName: String,
    val totalTimeInMillis: Long,
    val icon: Drawable?
)

object UsageStatsHelper {

    /** 小于 1 秒的使用记录视为误触，不计入 */
    private const val MIN_TRACKED_MS = 1_000L

    // ---------- 时间范围 ----------

    const val PERIOD_TODAY = 0
    const val PERIOD_WEEK = 1
    const val PERIOD_MONTH = 2

    fun rangeOf(period: Int): Pair<Long, Long> = when (period) {
        PERIOD_TODAY -> todayStart() to System.currentTimeMillis()
        PERIOD_WEEK -> weekStart() to System.currentTimeMillis()
        else -> monthStart() to System.currentTimeMillis()
    }

    private fun todayStart(): Long =
        Calendar.getInstance().apply {
            set(Calendar.HOUR_OF_DAY, 0)
            set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }.timeInMillis

    /** 本周从周一开始 */
    private fun weekStart(): Long =
        Calendar.getInstance().apply {
            firstDayOfWeek = Calendar.MONDAY
            set(Calendar.HOUR_OF_DAY, 0)
            set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
            set(Calendar.DAY_OF_WEEK, Calendar.MONDAY)
        }.timeInMillis

    private fun monthStart(): Long =
        Calendar.getInstance().apply {
            set(Calendar.DAY_OF_MONTH, 1)
            set(Calendar.HOUR_OF_DAY, 0)
            set(Calendar.MINUTE, 0)
            set(Calendar.SECOND, 0)
            set(Calendar.MILLISECOND, 0)
        }.timeInMillis

    // ---------- 核心统计 ----------

    /**
     * 遍历时间段内的事件流，把「进入前台 -> 离开前台」的间隔累加到对应包名。
     * 相比 queryAndAggregateUsageStats 的按天分桶统计，事件流方式在「今日」粒度上更精确。
     */
    private fun queryForegroundUsage(
        context: Context,
        startTime: Long,
        endTime: Long
    ): Map<String, Long> {
        val usm = context.getSystemService(Context.USAGE_STATS_SERVICE) as UsageStatsManager
        val usage = HashMap<String, Long>()
        val events = usm.queryEvents(startTime, endTime)
        val event = UsageEvents.Event()
        var openPackage: String? = null
        var openTime = -1L

        fun closeInterval(closeAt: Long) {
            val pkg = openPackage
            if (pkg != null && openTime in 1 until closeAt) {
                usage.merge(pkg, closeAt - openTime) { a, b -> a + b }
            }
            openPackage = null
            openTime = -1
        }

        while (events.hasNextEvent()) {
            events.getNextEvent(event)
            when (event.eventType) {
                UsageEvents.Event.ACTIVITY_RESUMED -> {
                    // 兜底：某些机型可能漏发 PAUSED，进入新前台时先结算上一个区间
                    closeInterval(event.timeStamp)
                    openPackage = event.packageName
                    openTime = event.timeStamp
                }
                UsageEvents.Event.ACTIVITY_PAUSED -> closeInterval(event.timeStamp)
            }
        }
        // 查询结束时仍在前台的应用
        closeInterval(endTime)
        return usage
    }

    /** 查询一段时间内各应用的使用时长，只保留有启动器入口的应用，按时长降序 */
    fun loadAppUsageInfos(context: Context, startTime: Long, endTime: Long): List<AppUsageInfo> {
        val usage = queryForegroundUsage(context, startTime, endTime)
        val pm = context.packageManager
        return usage.entries.asSequence()
            .filter { it.value >= MIN_TRACKED_MS }
            .mapNotNull { (pkg, time) ->
                if (pm.getLaunchIntentForPackage(pkg) == null) return@mapNotNull null
                val appInfo = runCatching { pm.getApplicationInfo(pkg, 0) }.getOrNull()
                    ?: return@mapNotNull null
                AppUsageInfo(
                    packageName = pkg,
                    appName = appInfo.loadLabel(pm).toString(),
                    totalTimeInMillis = time,
                    icon = runCatching { pm.getApplicationIcon(pkg) }.getOrNull()
                )
            }
            .sortedByDescending { it.totalTimeInMillis }
            .toList()
    }

    // ---------- 展示辅助 ----------

    fun formatDuration(millis: Long): String {
        val totalSeconds = millis / 1000
        val hours = totalSeconds / 3600
        val minutes = (totalSeconds % 3600) / 60
        val seconds = totalSeconds % 60
        return when {
            hours > 0 -> if (minutes > 0) "${hours}小时${minutes}分钟" else "${hours}小时"
            minutes > 0 -> if (seconds > 0) "${minutes}分${seconds}秒" else "${minutes}分钟"
            else -> "${seconds}秒"
        }
    }

    fun rangeTitle(period: Int, start: Long, end: Long): String {
        val dayFmt = SimpleDateFormat("M月d日", Locale.getDefault())
        return when (period) {
            PERIOD_TODAY -> SimpleDateFormat("M月d日 EEEE", Locale.getDefault()).format(Date())
            else -> "${dayFmt.format(Date(start))} - ${dayFmt.format(Date(end))}"
        }
    }
}
