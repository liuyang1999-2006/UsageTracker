package com.usagetracker.app

import android.content.Intent
import android.os.Bundle
import android.provider.Settings
import android.view.View
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.DividerItemDecoration
import androidx.recyclerview.widget.LinearLayoutManager
import com.google.android.material.tabs.TabLayout
import com.usagetracker.app.databinding.ActivityMainBinding
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

class MainActivity : AppCompatActivity() {

    private lateinit var binding: ActivityMainBinding
    private lateinit var adapter: AppUsageAdapter

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)

        adapter = AppUsageAdapter()
        binding.recyclerView.layoutManager = LinearLayoutManager(this)
        binding.recyclerView.adapter = adapter
        binding.recyclerView.addItemDecoration(
            DividerItemDecoration(this, DividerItemDecoration.VERTICAL)
        )

        binding.tabLayout.addTab(binding.tabLayout.newTab().setText(R.string.tab_today))
        binding.tabLayout.addTab(binding.tabLayout.newTab().setText(R.string.tab_week))
        binding.tabLayout.addTab(binding.tabLayout.newTab().setText(R.string.tab_month))
        binding.tabLayout.addOnTabSelectedListener(object : TabLayout.OnTabSelectedListener {
            override fun onTabSelected(tab: TabLayout.Tab) = loadData()
            override fun onTabUnselected(tab: TabLayout.Tab) {}
            override fun onTabReselected(tab: TabLayout.Tab) = loadData()
        })

        binding.swipeRefresh.setColorSchemeResources(R.color.primary)
        binding.swipeRefresh.setOnRefreshListener { loadData() }

        binding.grantButton.setOnClickListener {
            startActivity(Intent(Settings.ACTION_USAGE_ACCESS_SETTINGS))
        }
    }

    override fun onResume() {
        super.onResume()
        // 从系统设置授权页返回时在这里重新检查权限并刷新数据
        refreshPermissionState()
    }

    private fun refreshPermissionState() {
        val granted = PermissionUtils.hasUsageAccess(this)
        binding.permissionView.visibility = if (granted) View.GONE else View.VISIBLE
        binding.contentView.visibility = if (granted) View.VISIBLE else View.GONE
        if (granted) loadData()
    }

    private fun loadData() {
        val period = binding.tabLayout.selectedTabPosition.coerceAtLeast(0)
        val (start, end) = UsageStatsHelper.rangeOf(period)
        binding.dateRangeText.text = UsageStatsHelper.rangeTitle(period, start, end)
        binding.swipeRefresh.isRefreshing = true

        lifecycleScope.launch {
            val result = runCatching {
                withContext(Dispatchers.IO) {
                    UsageStatsHelper.loadAppUsageInfos(this@MainActivity, start, end)
                }
            }
            binding.swipeRefresh.isRefreshing = false
            result
                .onSuccess { list ->
                    val total = list.sumOf { it.totalTimeInMillis }
                    binding.totalTimeText.text =
                        getString(R.string.total_time_format, UsageStatsHelper.formatDuration(total))
                    binding.appCountText.text = getString(R.string.app_count_format, list.size)
                    adapter.submit(list)
                    binding.emptyView.visibility = if (list.isEmpty()) View.VISIBLE else View.GONE
                }
                .onFailure {
                    adapter.submit(emptyList())
                    binding.emptyView.visibility = View.VISIBLE
                    binding.totalTimeText.text =
                        getString(R.string.total_time_format, UsageStatsHelper.formatDuration(0))
                    binding.appCountText.text = getString(R.string.app_count_format, 0)
                    Toast.makeText(this@MainActivity, R.string.load_failed, Toast.LENGTH_SHORT)
                        .show()
                }
        }
    }
}
