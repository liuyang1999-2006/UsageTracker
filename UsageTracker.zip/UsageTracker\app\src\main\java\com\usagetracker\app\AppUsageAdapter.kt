package com.usagetracker.app

import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.usagetracker.app.databinding.ItemAppUsageBinding

class AppUsageAdapter : RecyclerView.Adapter<AppUsageAdapter.ViewHolder>() {

    private val items = mutableListOf<AppUsageInfo>()
    private var maxTime = 1L
    private var totalTime = 1L

    fun submit(list: List<AppUsageInfo>) {
        items.clear()
        items.addAll(list)
        maxTime = (items.maxOfOrNull { it.totalTimeInMillis } ?: 0L).coerceAtLeast(1L)
        totalTime = items.sumOf { it.totalTimeInMillis }.coerceAtLeast(1L)
        notifyDataSetChanged()
    }

    class ViewHolder(val binding: ItemAppUsageBinding) : RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val binding =
            ItemAppUsageBinding.inflate(LayoutInflater.from(parent.context), parent, false)
        return ViewHolder(binding)
    }

    override fun getItemCount(): Int = items.size

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        val item = items[position]
        with(holder.binding) {
            rankText.text = (position + 1).toString()
            appIcon.setImageDrawable(item.icon)
            appName.text = item.appName
            packageText.text = item.packageName
            timeText.text = UsageStatsHelper.formatDuration(item.totalTimeInMillis)
            percentText.text = "${item.totalTimeInMillis * 100 / totalTime}%"
            usageBar.progress = ((item.totalTimeInMillis * 100) / maxTime)
                .toInt().coerceIn(0, 100)
        }
    }
}
